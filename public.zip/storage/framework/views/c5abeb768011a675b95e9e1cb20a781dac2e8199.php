
<?php $__env->startSection('content'); ?>
    <h3 class="text-center">Edit Todo</h3>
    <form action="<?php echo e(route('todos.update',$todo->id)); ?>" method="post">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>
        <div class="md-form">
            <label for="title">Todo Title</label>
            <input type="text" name="title" id="title" class="form-control <?php echo e($errors->has('title') ? 'is-invalid' : ''); ?>" value="<?php echo e(old('title') ? : $todo->title); ?>" placeholder="Enter Title">
            <?php if($errors->has('title')): ?> 
                <span class="invalid-feedback">
                    <?php echo e($errors->first('title')); ?> 
                </span>
            <?php endif; ?>
        </div>
        <style>
            .md-form label.active {
                -webkit-transform: translateY(-25px) scale(0.8);
                transform: translateY(-25px) scale(0.8);
            }
        </style>
        <div class="md-form mt-5">
            <label for="body" class="mb-4">Todo Description</label>
            <textarea name="body" id="body" rows="4" class="md-textarea mt-4 form-control <?php echo e($errors->has('body') ? 'is-invalid' : ''); ?>" placeholder="Enter Todo Description"><?php echo e(old('body') ? : $todo->body); ?></textarea>
            <?php if($errors->has('body')): ?> 
                <span class="invalid-feedback">
                    <?php echo e($errors->first('body')); ?> 
                </span>
            <?php endif; ?>
        </div>
        <button type="submit" class="btn blue-gradient btn-block">Update</button>
    </form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laraapp\resources\views/todos/edit.blade.php ENDPATH**/ ?>