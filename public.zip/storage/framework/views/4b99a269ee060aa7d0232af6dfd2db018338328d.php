<!-- Footer -->
<footer class="page-footer font-small bg-secondary fixed-bottom">

    <!-- Copyright -->
    <div class="footer-copyright text-center py-3">© 2020 Copyright:
      <a href="https://rupesh.cf/"> Rupesh Chaudhari </a>
    </div>
    <!-- Copyright -->
  
  </footer>
  <!-- Footer --><?php /**PATH C:\xampp\htdocs\laraapp\resources\views/includes/footer.blade.php ENDPATH**/ ?>