

<?php $__env->startSection('content'); ?>
    <style>
        .logo-img{
            height:auto;
            width:40vw;
            position: relative;
            left:27.5%;
            margin: 5% 0;
        }
    </style>
    <img src="<?php echo e(url('assets/logo.svg')); ?>" class="img img-responsive logo-img "  alt="" srcset="">
    
    <p class="text-center h3">An application to help you organize your tasks.</p>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laraapp\resources\views/pages/index.blade.php ENDPATH**/ ?>