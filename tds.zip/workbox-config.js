module.exports = {
  "globDirectory": "public/",
  "globPatterns": [
    "**/*.{ogg,png,css,jpg,js,svg,json,ico,php,txt}"
  ],
  "swDest": "public/sw.js"
};