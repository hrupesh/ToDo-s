
<?php $__env->startSection('content'); ?>
    <h3 class="text-center">Create Todo</h3>
    <form action="<?php echo e(route('todos.store')); ?>" method="post">
        <?php echo csrf_field(); ?>
        <div class="md-form">
            <input type="text" required name="title" id="title" class="form-control <?php echo e($errors->has('title') ? 'is-invalid' : ''); ?>" value="<?php echo e(old('title')); ?>" >
            <label for="title">Todo Title</label>
            <?php if($errors->has('title')): ?>
                <span class="invalid-feedback">
                    <?php echo e($errors->first('title')); ?>

                </span>
            <?php endif; ?>
        </div>
        <div class="md-form">
            <textarea name="body" required id="body" rows="4" class="md-textarea form-control <?php echo e($errors->has('body') ? 'is-invalid' : ''); ?>"  ><?php echo e(old('body')); ?></textarea>
            <label for="body">Todo Description</label>
            <?php if($errors->has('body')): ?> 
                <span class="invalid-feedback">
                    <?php echo e($errors->first('body')); ?> 
                </span>
            <?php endif; ?>
        </div>
        <button type="submit" class="btn purple-gradient  waves-effect">Create</button>
    </form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laraapp\resources\views/todos/create.blade.php ENDPATH**/ ?>