
<?php $__env->startSection('content'); ?>
    <h3 class="text-center">Edit Profile</h3>
    <form action="<?php echo e(route('profile.update')); ?>" method="post" enctype="multipart/form-data"> 
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>
        <div class="form-group">
            <label for="name">Name</label>
            <input type="text" name="name" id="name" class="form-control <?php echo e($errors->has('name') ? 'is-invalid' : ''); ?>" value="<?php echo e(old('name') ? : Auth::user()->name); ?>" placeholder="Enter Name">
            <?php if($errors->has('name')): ?>
                <span class="invalid-feedback">
                    <?php echo e($errors->first('name')); ?>

                </span>
            <?php endif; ?>
        </div>
        <div class="form-group">
            <label for="email">Email</label>
            <input type="email" name="email" id="email" class="form-control <?php echo e($errors->has('name') ? 'is-invalid' : ''); ?>" value="<?php echo e(old('email') ? : Auth::user()->email); ?>" placeholder="Enter Email">
            <?php if($errors->has('email')): ?>
                <span class="invalid-feedback">
                    <?php echo e($errors->first('email')); ?>

                </span>
            <?php endif; ?>
        </div>
        <div class="form-group">
            <label for="password">Password</label>
            <input type="password" name="password" id="password" class="form-control <?php echo e($errors->has('password') ? 'is-invalid' : ''); ?>" placeholder="Enter Password">
            <?php if($errors->has('password')): ?>
                <span class="invalid-feedback">
                    <?php echo e($errors->first('password')); ?>

                </span>
            <?php endif; ?>
        </div>
        <div class="custom-file">
            <input type="file" name="image" class="custom-file-input <?php echo e($errors->has('image') ? 'is-invalid' : ''); ?>" id="image">
            <label class="custom-file-label" for="image">Profile Image</label>
            <?php if($errors->has('image')): ?>
                <span class="invalid-feedback">
                    <?php echo e($errors->first('image')); ?>

                </span>
            <?php endif; ?>
        </div>
        <button type="submit" class="btn btn-primary mt-3">Update</button>
    </form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laraapp\resources\views/user/profile.blade.php ENDPATH**/ ?>